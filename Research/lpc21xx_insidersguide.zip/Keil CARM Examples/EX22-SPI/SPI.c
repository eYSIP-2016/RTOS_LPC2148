                  
#include <LPC21xx.H>               // LPC21xx definitions


static void SPI0_Init(void)
{
   // PINSEL0 |= 0x5500;             // configure SPI0 pins
PINSEL1	= 0x2A8;
    S1SPCCR = 12;                  // SCK = 1 MHz, counter > 8 and even
    S1SPCR  = 0x20;                // Master, no interrupt enable
}


int main (void)
{
    // Fosc = 12.000.000 MHz, PLL not used
  volatile unsigned result;
    
    SPI0_Init();

    while (1)
    {
		result = S1SPDR;
        S1SPDR  = 0xAA;                // send next SPI channel 0 data
        while (!(S1SPSR & 0x80)) ;     // wait for transfer completed
    }
}
