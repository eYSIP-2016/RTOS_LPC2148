/******************************************************************************/
/*  This file is part of the uVision/ARM development tools                    */
/*  Copyright KEIL ELEKTRONIK GmbH 2002-2004                                  */
/******************************************************************************/
/*                                                                            */
/*  HELLO.C:  Hello World Example                                             */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>                          /* I/O Functions */
#include <LPC22XX.H>                        /* LPC22XX Peripheral Registers */

unsigned Send_byte (unsigned Data);
void wait(void);
unsigned read_byte (void);

#define CS_HIGH IOSET0 = 0x400
#define CS_LOW  IOCLR0 = 0x400

 unsigned result= 0;
 unsigned result2 = 0;

int main (void)  
{

PINSEL0 = 0x5500;					 //Select SPI pins and enable SSEL0
IODIR0 = 0x400;						 //Configure GPIO pin to control the CS on the SPI eeprom
CS_HIGH;				 			 //Set the pin High
VPBDIV = 0x04;						 //Set the Clock VBP clock to 60 Mhz

S0SPCCR = 0x000000C8;				//Set SPI bit rate at 300Khz
S0SPCR  = 0x00000020;				//set control register

wait();

CS_LOW;
result =  Send_byte(0x55);


wait();


result = Send_byte(0x01);
result = read_byte;


wait();


result =  Send_byte(0x05);

while(1)
{
;
}

}

unsigned Send_byte (unsigned Data)
{
unsigned int result;
result = S0SPSR;
 S0SPDR = Data;
 while(S0SPSR == 0)
 {
 ;
 }
return S0SPSR;
}

unsigned read_byte (void)
{
 while(S0SPSR == 0)
 {
 ;
 }
return S0SPDR;
}

void wait(void)
{
unsigned delay;
for(delay = 0;delay<0x10000;delay++)	//a bit of setteling time
{
;
}
}
 