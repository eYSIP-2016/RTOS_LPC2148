/************************************************************/
/* PROJECT NAME: Thumb	                                    */
/* Project:      LPC2100 Training course                    */
/* Engineer:     T Martin   tmartin@hitex.co.uk             */
/* Filename:     thumb.c                                    */
/* Language:     C                      	                */
/* Compiler:     Keil Arm	V1.3		                    */
/* Assembler:    				                            */
/*                                                          */
/************************************************************/
/* COPYRIGHT: Hitex UK Ltd 		2004						*/
/* LICENSE:   THIS VERSION CREATED FOR FREE DISTRIBUTION	*/
/************************************************************/
/* Function:                                                */
/*                                                          */
/* Example Thumb program for LPC2100              			*/
/*															*/
/* Demonstrates APCS and ARM - Thumb interworking			*/
/*															*/	
/* Oscillator frequency 12.000 Mhz							*/
/* Target board Keil MCB2100								*/
/************************************************************/


#include <LPC21XX.H>
 
void thumb_function(void);

#pragma THUMB

void thumb_function(void)
{
unsigned long i,delay;

for (i = 0x00010000;i < 0x01000000 ;i = i<<1)	  //LED flasher	
{

for (delay = 0;delay<0x000100000;delay++)		 //simple delay loop
{
;
}
IOSET1 = i;										//Set the next led
}
}

#pragma ARM

