/************************************************************/
/* PROJECT NAME: Thumb	                                    */
/* Project:      LPC2100 Training course                    */
/* Engineer:     T Martin     tmartin@hitex.co.uk           */
/* Filename:     main.c	                                    */
/* Language:     C                      	                */
/* Compiler:     Keil ARM 	V2.00b		                    */
/* Assembler:    				                            */
/*                                                          */
/************************************************************/
/* COPYRIGHT: Hitex UK Ltd 		2004						*/
/* LICENSE:   THIS VERSION CREATED FOR FREE DISTRIBUTION	*/
/************************************************************/
/* Function:                                                */
/*                                                          */
/* Example Thumb program for LPC2100              			*/
/*															*/
/* Demonstrates APCS and ARM - Thumb interworking			*/
/*															*/	
/* Oscillator frequency 12.000 Mhz							*/
/* Target board Keil MCB2100								*/
/************************************************************/

#include <LPC21xx.H> 

void thumb_function(void); 		//External prototype for thumb function

int main(void)	 __arm
{
IODIR1 = 0x00FF0000;


while(1)
{
IOCLR1 = 0x00FF0000;
thumb_function();						//Call Thumb function
}
}



void thumb_function(void) __thumb
{
unsigned int i,delay;

for (i = 0x00001000;i < 0x01000000 ;i = i<<1)	  //LED flasher	
{

for (delay = 0;delay<0x010000;delay++)		 //simple delay loop
{
;
}
IOSET1 = i;										//Set the next led
}
}




