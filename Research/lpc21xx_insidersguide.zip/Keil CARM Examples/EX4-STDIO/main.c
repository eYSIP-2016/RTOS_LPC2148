/************************************************************/
/* PROJECT NAME: Standard IO                                */
/* Project:      LPC2100 Training course                    */
/* Engineer:     T Martin    tmartin@hitex.co.uk            */
/* Filename:     main.c	                                    */
/* Language:     C                      	                */
/* Compiler:     Keil ARM	V2.00b		                    */
/* Assembler:    				                            */
/*                                                          */
/************************************************************/
/* COPYRIGHT: Hitex UK Ltd 		2005						*/
/* LICENSE:   THIS VERSION CREATED FOR FREE DISTRIBUTION	*/
/************************************************************/
/* Function:                                                */
/*                                                          */
/* Example Standard I/O program for LPC2100        			*/
/*															*/
/* Demonstrates interfacing STDIO library function 			*/
/* to low level drivers										*/
/*															*/	
/* Oscillator frequency 12.000 Mhz							*/
/* Target board Keil MCB2100								*/
/************************************************************/

#include <LPC21xx.H> 
#include <stdio.h>

void UART0 (void);


int main(void)
{
UART0 ();				   //Initilise the UART

while(1)
{
printf("\n\n\nHello World, well its traditional \n"); //Call the prinff function

}

}



void UART0 (void)	
{
PINSEL0 = 0x05; 		// Select TxD and RxD on pin connect block
U0LCR = 0x80;			//Enable programming of divisor latches

U0DLL = 0xC2;			//Program the divisor latch for 19200 baud
U0DLM = 0x00;

U0LCR = 0x33;			//Program the line control 8\N\1
U0FCR = 0x4F;			//enable the FIFO's
			
}






