/************************************************************/
/* PROJECT NAME: Standard IO                                */
/* Project:      LPC2100 Training course                    */
/* Engineer:     T Martin    tmartin@hitex.co.uk            */
/* Filename:     serial.c                                   */
/* Language:     C                      	                */
/* Compiler:     Keil ARM	V2.00b		                    */
/* Assembler:    				                            */
/*                                                          */
/************************************************************/
/* COPYRIGHT: Hitex UK Ltd 		2005						*/
/* LICENSE:   THIS VERSION CREATED FOR FREE DISTRIBUTION	*/
/************************************************************/
/* Function:                                                */
/*                                                          */
/* Example Standard I/O program for LPC2100        			*/
/*															*/
/* Demonstrates interfacing STDIO library function 			*/
/* to low level drivers										*/
/*															*/	
/* Oscillator frequency 12.000 Mhz							*/
/* Target board Keil MCB2100								*/
/************************************************************/

#define CR     0x0D

#include <LPC21xx.H> 
int putchar (int ch);

int putchar (int ch) 
{                    /* Write character to Serial Port  */

  if (ch == '\n')  
  {
    while (!(U0LSR & 0x20));
    U0THR = CR;                          /* output CR */
  }
  while (!(U0LSR & 0x20));

  
  return (U0THR = ch);
}


