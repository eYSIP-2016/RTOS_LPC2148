#include <math.h>
#include <LPC213X.H>
void init_timer (void);
 
void main(void)
{
unsigned int val;
unsigned char index,loop;
VPBDIV 			= 0x02;						//Set the Pclk to 30 Mhz
IODIR1 			= 0x00FF0000;    			// P1.16..23 defined as Outputs  
AD0CR  			= 0x00250601;    			// Setup A/D: 10-bit AIN0 @ 3MHz 
AD0CR  			|= 0x01000000;    			// Start A/D Conversion 

while(1)
{
for(index = 0;index<80;index++)
{		  
do
{
    val 		= AD0DR;                   	// Read A/D Data Register 
}        
while ((val & 0x80000000) == 0);  			//Wait for the conversion to complete

DACR 			= val;
}

}

}

