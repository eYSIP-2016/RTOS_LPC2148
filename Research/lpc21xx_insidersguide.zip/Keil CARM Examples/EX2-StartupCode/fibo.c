/************************************************************/
/* PROJECT NAME: First 	                                    */
/* Project:      LPC2100 Training course                    */
/* Engineer:     T Martin                                   */
/* Filename:     Fibo.C                                     */
/* Language:     C                      	                */
/* Compiler:     Keil CARM Ver 2.00b			            */
/* Assembler:    				                            */
/*                                                          */
/************************************************************/
/* Modification History:                                    */
/*                                                          */
/************************************************************/
/* Function:                                                */
/*                                                          */
/* Startup code example				            			*/
/*															*/
/* Demonstrates Startup code and project layout				*/
/*															*/	
/* Oscillator frequency 12.00 Mhz							*/
/* Target board Keil MCB2100								*/
/************************************************************/

unsigned int fiboCount;
unsigned int counter;


unsigned int Fibonacci(unsigned int n)
{
  unsigned fib1, fib2, fibo;
  int i;

  fib1 = 0;
  fib2 = 1;
  fibo = n;
  i = 2;  
  while (i <= n) { 
    fibo = fib1 + fib2;       
    fib1 = fib2;
    fib2 = fibo;
    i++;       
  }             
  return(fibo);
}

int main(void)
{ 

   int i;

     for (;;)
   {
      counter = 0;
      for (i = 0; i <= 20; i++)
      {
         counter++;
         fiboCount = Fibonacci(counter);
      }      
   }
}
