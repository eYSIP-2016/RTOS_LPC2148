# Fi-Pi
Firebird-V controlled robot using raspberry pi

Feedback will be highly appreciable. Please send an email to sauravs.iitb@gmail.com

Details visit [wiki page] (https://github.com/sauravshandilya/Fi-Pi/wiki)
